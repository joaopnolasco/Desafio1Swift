import SwiftUI

let Steve = "Steve"
 
var nome: String? = "Jobs"

let constante = "Steve"


print("Nome completo: \(constante) \(nome ?? "Wozniak")")



